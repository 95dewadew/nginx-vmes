<?php
$IPINFO_APIKEY="a97867112a6b3e"; //put your token between the quotes if you have one
?>